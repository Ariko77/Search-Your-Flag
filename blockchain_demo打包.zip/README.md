# 简化区块链可视化（教师可定制）

这个小演示页面用于课堂教学，帮助新手理解**区块链不可篡改**的概念。页面是静态 HTML，仅在浏览器运行，无需后端。

## 功能简介
- 展示 5 个“区块”，第 4 个初始为 **tampered（红色）**。
- 学生需要在链上查找老师部署的合约地址并把该地址复制粘贴到第 4 个区块的 **To** 字段，点击 **Check**。
- 当地址与教师在页面 CONFIG 中配置的 `EXPECTED_TO` 匹配时，页面会把第 4 个区块标记为 Valid（绿色），并把第 4 区块的 `Nonce` 字段显示为 `FLAG_NONCE`（即 flag）。

## 教师使用说明（如何定制）
1. 打开 `index.html`，在顶部 `CONFIG` 区域找到：
```js
const CONFIG = {
  EXPECTED_TO: "0x1234567890abcdef1234567890abcdef12345678",
  FLAG_NONCE: "FLAG{nonce_is_42}"
};
```
2. 把 `EXPECTED_TO` 改为你在测试网上部署合约的地址（老师部署合约并把合约地址提供给题目）。
3. 把 `FLAG_NONCE` 改为你想要的 flag（例如 `FLAG{student_001}`），保存文件。
4. 把文件上传到你想托管的静态站点（例如 GitHub Pages、Netlify 或你自己的服务器）。

## 部署到 GitHub Pages（快速步骤）
1. 登录 GitHub，创建新仓库（Public），把 `index.html` 和 `README.md` 上传到仓库根目录（可直接在网页上 `Add file -> Upload files`）。
2. 仓库页面点击 `Settings -> Pages`，选择 `main` 分支的 `/ (root)`，保存。
3. 等待几分钟，GitHub 会提供你的页面地址：`https://<用户名>.github.io/<仓库名>/`，学生即可访问。

## 教学建议（课堂流程）
1. 先演示“改一格 Data → 挖矿 → 链断裂”的过程（若你想更直观，可同时打开原始 Anders Brownworth 的在线 demo）。
2. 把学生分组，让他们上网查合约地址（老师在测试网部署的合约），并把地址粘贴到页面第 4 区块的 To 字段→ 点击 Check。 
3. 学生看到 nonce 字段变为 flag（显示成功），截图提交作业。

## 注意事项
- 这里的 demo 只是教学可视化，不做真实链上写入/验证。flag 是通过前端匹配地址后显示的，老师需要把 `EXPECTED_TO` 设置成已部署合约地址以避免作弊。
- 若要更防刷，可以为每个学生生成不同 flag 并分别在每个学生的专属页面配置或生成一次性 token。

